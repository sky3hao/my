-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 03 月 23 日 19:24
-- 服务器版本: 5.1.63
-- PHP 版本: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `s554674db0`
--

-- --------------------------------------------------------

--
-- 表的结构 `task_article`
--

CREATE TABLE IF NOT EXISTS `task_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `title` varchar(300) NOT NULL,
  `status` tinyint(10) NOT NULL DEFAULT '0' COMMENT '0:未审核    1: 待审      2：审核通过  3：审核未通过',
  `comment` varchar(300) NOT NULL DEFAULT '' COMMENT '显示未通过原因',
  `task_id` varchar(100) NOT NULL DEFAULT 'null',
  `user_id` varchar(100) NOT NULL DEFAULT 'null',
  `date` varchar(100) NOT NULL DEFAULT 'null',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `task_task`
--

CREATE TABLE IF NOT EXISTS `task_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords` varchar(400) NOT NULL,
  `wordNumber` varchar(100) NOT NULL,
  `count` varchar(100) NOT NULL,
  `remain` int(100) NOT NULL DEFAULT '0',
  `start_time` int(100) NOT NULL DEFAULT '0',
  `period` int(100) NOT NULL DEFAULT '0',
  `date` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `task_user`
--

CREATE TABLE IF NOT EXISTS `task_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `login_time` int(11) NOT NULL DEFAULT '0',
  `register_time` int(11) NOT NULL DEFAULT '0',
  `type` varchar(100) NOT NULL DEFAULT 'normal' COMMENT 'admin:管理员  normal:普通用户',
  `alipay` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL COMMENT '0:禁止登入 1:允许登入',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `task_user`
--

INSERT INTO `task_user` (`id`, `username`, `email`, `password`, `phone`, `login_time`, `register_time`, `type`, `alipay`, `status`) VALUES
(1, 'admin', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', '123', 1364034090, 0, 'admin', '123456', 1),
(2, '温振林', 'silenceper@gmail.com', '0a26c80a46114477110f8e3fee4b714e', '111111111111', 1364034248, 0, 'normal', '123456', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
