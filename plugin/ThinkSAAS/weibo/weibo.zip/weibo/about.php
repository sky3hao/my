<?php
/*
 * 微博登入插件
*
* @ silenceper@gmail.com
*   2012_09_26
* */
defined('IN_TS') or die('Access Denied.');
return array(
'name' => '微博登录outh2.0',
'version' => '2.0',
'desc' => '用户微博帐号登录由ThinkSAAS搭建的社区',
'url' => 'http://www.zzblo.com',
'email' => 'silenceper@gmail.com',
'author' => 'silenceper',
'author_url' => 'http://www.zzblo.com',
'isedit'	=> '1',
);
