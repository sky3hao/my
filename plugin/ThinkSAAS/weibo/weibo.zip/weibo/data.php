<?php
defined('IN_TS') or die('Access Denied.');
return array (
  'wb_akey' => 'XXXXXX',
  'wb_skey' => 'XXXXXXXXXXXXXXXXXXXXXXXXXXX',
  'siteurl' => 'XXXXXXXXXXX',
);